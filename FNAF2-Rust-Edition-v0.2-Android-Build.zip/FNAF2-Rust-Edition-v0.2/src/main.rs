fn main() {
    fnaf2_rust_edition::main();
}
