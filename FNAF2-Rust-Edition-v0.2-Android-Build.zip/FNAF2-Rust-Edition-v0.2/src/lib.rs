use bevy::prelude::*;

mod game;

// Bevy generates the Android entry point for the selected Android Activity.
// The desktop binary calls this same function through the library.
#[cfg_attr(target_os = "android", bevy_main)]
pub fn main() {
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "FNAF 2: Rust Edition".into(),
                resolution: (960.0, 540.0).into(),
                resizable: true,
                ..default()
            }),
            ..default()
        }))
        .init_resource::<game::GameState>()
        .add_systems(Startup, game::setup)
        .add_systems(
            Update,
            (
                game::clock_tick,
                game::keyboard_controls,
                game::touch_controls,
                game::button_interactions,
                game::refresh_hud,
                game::animatronic_ai,
            ),
        )
        .run();
}
