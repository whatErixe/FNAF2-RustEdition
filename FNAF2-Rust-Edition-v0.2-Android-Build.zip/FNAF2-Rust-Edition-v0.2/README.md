# FNAF 2: Rust Edition — Android Build Edition 0.2

A fan-made prototype inspired by the mechanics of Five Nights at Freddy's 2.
This project is an original implementation and does not include original game
art, audio, source code, or other copyrighted game assets.

## Stack
- Rust
- Bevy 0.15
- Android GameActivity
- Gradle / Android SDK / Android NDK
- GitHub Actions (cloud APK build)

## Current prototype features
- Bevy game window and placeholder office scene
- HUD with night clock, flashlight charge and music-box meter
- Monitor toggle and five placeholder camera labels
- Mask and flashlight controls
- Music-box winding control
- Basic timed animatronic activity messages
- On-screen touch buttons and keyboard controls for desktop testing

## Android build through GitHub Actions
1. Upload the entire repository contents to the root of your GitHub repository.
2. Make sure `.github/workflows/android.yml` is present on the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Press **Run workflow** (or push a commit to `main`).
6. When the run completes, open it and download the artifact named
   `FNAF2-RustEdition-Android-debug`.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow builds an arm64-v8a APK. It uses Bevy's GameActivity backend,
Android API 26 as the native build platform level, Android SDK 34, and Java 17.

## Desktop test
With Rust installed, run:

```bash
cargo run --bin fnaf2-rust-edition-desktop
```

## Project structure

```text
.github/workflows/android.yml  # Cloud APK build
.cargo/config.toml             # Cargo cross-build notes
android/                       # Gradle Android application
  app/src/main/                # Manifest, Activity, assets and native libs
src/
  main.rs                      # Desktop entry point
  lib.rs                       # Shared Bevy app / Android entry point
  game.rs                      # Prototype game systems
assets/
  images/
  sounds/
Cargo.toml
README.md
```

## Notes
- This is a prototype scaffold, not a finished FNAF game.
- The first CI run is the real compile test. If it fails, open the failed
  GitHub Actions job and share the first relevant error section so the
  project can be corrected.
- The APK is a debug build signed with Android's debug signing configuration.
- `minSdk` is 26 (Android 8.0) for this prototype.
